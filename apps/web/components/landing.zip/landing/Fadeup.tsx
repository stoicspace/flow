"use client";

// Optional scroll-reveal wrapper. Install `framer-motion` to enable it:
//   npm install framer-motion
// then uncomment the implementation below and use <FadeUp> around any section.

// import { motion } from "framer-motion";
//
// interface FadeUpProps {
//   children: React.ReactNode;
//   delay?: number;
// }
//
// export default function FadeUp({ children, delay = 0 }: FadeUpProps) {
//   return (
//     <motion.div
//       initial={{ opacity: 0, y: 50 }}
//       whileInView={{ opacity: 1, y: 0 }}
//       transition={{ duration: 0.6, delay }}
//       viewport={{ once: true }}
//     >
//       {children}
//     </motion.div>
//   );
// }

interface FadeUpProps {
  children: React.ReactNode;
  delay?: number;
}

export default function FadeUp({ children }: FadeUpProps) {
  return <div>{children}</div>;
}