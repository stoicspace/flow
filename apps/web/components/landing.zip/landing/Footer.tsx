export default function Footer() {
  return (
    <footer className="border-t border-white/10 py-20" id="footer">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-1 gap-10">
          <div>
            <h2 className="text-2xl font-bold">FlowLens</h2>
            <p className="mt-5 text-gray-400 leading-7">
              Automation observability made easy.
            </p>
          </div>

          <div>
            <h3 className="font-semibold mb-6">Join Waitlist Now</h3>
          </div>
        </div>

        <div className="mt-20 border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500">
            © {new Date().getFullYear()} FlowLens. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}